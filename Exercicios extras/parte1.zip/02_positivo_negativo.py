num = int(input('Informe um numero: '))

if (num > 0):
    print(num, 'eh positivo')
elif (num < 0):
    print(num, 'eh negativo')
else:
    print('O numero eh igual a 0')
