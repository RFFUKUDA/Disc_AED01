print('Loja Quase Dois - Tabela de preços')
for i in range(1, 51):
    print(f'{i:2d} - R$ {(i * 1.99):5.2f}')